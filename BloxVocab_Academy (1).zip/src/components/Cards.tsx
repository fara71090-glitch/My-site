import { motion } from "framer-motion";
import { Volume2, Lock, Unlock, TrendingUp, Award, Target } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge as BadgeUI } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { IMAGES } from "@/assets/images";
import type { Word, Exercise, Badge, UserProgress } from "@/lib/index";
import { springPresets, hoverLift } from "@/lib/motion";

interface WordCardProps {
  word: Word;
}

export function WordCard({ word }: WordCardProps) {
  const categoryColors = {
    slang: "bg-accent/20 text-accent border-accent/50",
    trading: "bg-primary/20 text-primary border-primary/50",
    mechanics: "bg-chart-3/20 text-chart-3 border-chart-3/50",
  };

  const handlePlayAudio = () => {
    if (word.audioUrl) {
      const audio = new Audio(word.audioUrl);
      audio.play();
    }
  };

  return (
    <motion.div
      variants={hoverLift}
      initial="rest"
      whileHover="hover"
      className="h-full"
    >
      <Card className="h-full bg-card/50 backdrop-blur-sm border-2 border-primary/30 hover:border-primary/60 transition-all duration-300 shadow-[0_8px_30px_-6px_color-mix(in_srgb,var(--primary)_15%,transparent)]">
        <CardHeader className="space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <CardTitle className="text-2xl font-bold text-foreground mb-1">
                {word.english}
              </CardTitle>
              <p className="text-sm text-muted-foreground font-mono">
                {word.transcription}
              </p>
            </div>
            {word.audioUrl && (
              <Button
                size="icon"
                variant="ghost"
                onClick={handlePlayAudio}
                className="shrink-0 hover:bg-primary/20 hover:text-primary transition-colors"
              >
                <Volume2 className="h-5 w-5" />
              </Button>
            )}
          </div>
          <BadgeUI className={`w-fit ${categoryColors[word.category]}`}>
            {word.category.toUpperCase()}
          </BadgeUI>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-lg font-semibold text-foreground mb-2">
              {word.russian}
            </p>
          </div>
          {word.examples.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Примеры из чата:
              </p>
              {word.examples.map((example, idx) => (
                <div
                  key={idx}
                  className="bg-muted/50 rounded-lg p-3 space-y-1 border border-border/50"
                >
                  <p className="text-sm text-foreground font-mono">
                    {example.english}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {example.russian}
                  </p>
                </div>
              ))}
            </div>
          )}
          {word.synonyms && word.synonyms.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide w-full">
                Синонимы:
              </p>
              {word.synonyms.map((synonym, idx) => (
                <BadgeUI
                  key={idx}
                  variant="outline"
                  className="text-xs border-primary/30"
                >
                  {synonym}
                </BadgeUI>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

interface ExerciseCardProps {
  exercise: Exercise;
  onStart: () => void;
}

export function ExerciseCard({ exercise, onStart }: ExerciseCardProps) {
  const difficultyColors = {
    beginner: "bg-chart-3/20 text-chart-3 border-chart-3/50",
    intermediate: "bg-chart-4/20 text-chart-4 border-chart-4/50",
    advanced: "bg-destructive/20 text-destructive border-destructive/50",
  };

  const typeIcons: Record<string, string> = {
    "match-pair": "🔗",
    "chat-repair": "💬",
    "word-builder": "🔨",
    "fill-blanks": "📝",
    "image-quiz": "🖼️",
    "true-false": "✓✗",
  };

  return (
    <motion.div
      variants={hoverLift}
      initial="rest"
      whileHover="hover"
      className="h-full"
    >
      <Card className="h-full bg-card/50 backdrop-blur-sm border-2 border-accent/30 hover:border-accent/60 transition-all duration-300 shadow-[0_8px_30px_-6px_color-mix(in_srgb,var(--accent)_15%,transparent)] flex flex-col">
        <CardHeader className="space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="text-4xl">{typeIcons[exercise.type]}</div>
            <BadgeUI className={`shrink-0 ${difficultyColors[exercise.difficulty]}`}>
              {exercise.difficulty === "beginner" && "Новичок"}
              {exercise.difficulty === "intermediate" && "Средний"}
              {exercise.difficulty === "advanced" && "Продвинутый"}
            </BadgeUI>
          </div>
          <CardTitle className="text-xl font-bold text-foreground">
            {exercise.title}
          </CardTitle>
          <CardDescription className="text-sm text-muted-foreground">
            {exercise.description}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col justify-end space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Award className="h-4 w-4 text-primary" />
            <span className="font-semibold">{exercise.points} очков</span>
          </div>
          <Button
            onClick={onStart}
            className="w-full bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 text-accent-foreground font-bold shadow-[0_4px_12px_color-mix(in_srgb,var(--accent)_35%,transparent),inset_0_1px_0_rgba(255,255,255,0.1),inset_0_-1px_0_rgba(0,0,0,0.1)] transition-all duration-200 hover:scale-[1.02] active:scale-[0.97]"
          >
            Начать
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}

interface BadgeCardProps {
  badge: Badge;
  unlocked: boolean;
}

export function BadgeCard({ badge, unlocked }: BadgeCardProps) {
  const rarityColors = {
    common: "from-muted to-muted/80",
    rare: "from-primary to-primary/80",
    epic: "from-accent to-accent/80",
    legendary: "from-chart-4 to-chart-4/80",
  };

  const rarityBorders = {
    common: "border-muted",
    rare: "border-primary",
    epic: "border-accent",
    legendary: "border-chart-4",
  };

  const badgeImages: Record<string, string> = {
    common: IMAGES.BADGES_1,
    rare: IMAGES.BADGES_3,
    epic: IMAGES.BADGES_5,
    legendary: IMAGES.BADGES_5,
  };

  return (
    <motion.div
      variants={hoverLift}
      initial="rest"
      whileHover={unlocked ? "hover" : "rest"}
      className="h-full"
    >
      <Card
        className={`h-full relative overflow-hidden border-2 transition-all duration-300 ${
          unlocked
            ? `${rarityBorders[badge.rarity]} shadow-[0_8px_30px_-6px_color-mix(in_srgb,var(--primary)_15%,transparent)]`
            : "border-border/50 opacity-60"
        }`}
      >
        <div
          className={`absolute inset-0 bg-gradient-to-br ${rarityColors[badge.rarity]} opacity-10`}
        />
        <CardHeader className="relative space-y-3">
          <div className="flex items-center justify-center">
            <div
              className={`relative w-24 h-24 rounded-full flex items-center justify-center ${
                unlocked ? "" : "grayscale"
              }`}
            >
              <img
                src={badgeImages[badge.rarity]}
                alt={badge.name}
                className="w-full h-full object-cover rounded-full"
              />
              {!unlocked && (
                <div className="absolute inset-0 flex items-center justify-center bg-background/80 rounded-full">
                  <Lock className="h-8 w-8 text-muted-foreground" />
                </div>
              )}
              {unlocked && (
                <div className="absolute -top-1 -right-1 bg-chart-3 rounded-full p-1">
                  <Unlock className="h-4 w-4 text-background" />
                </div>
              )}
            </div>
          </div>
          <div className="text-center space-y-1">
            <CardTitle className="text-lg font-bold text-foreground">
              {badge.name}
            </CardTitle>
            <BadgeUI
              className={`${rarityColors[badge.rarity]} text-white border-0`}
            >
              {badge.rarity === "common" && "Обычный"}
              {badge.rarity === "rare" && "Редкий"}
              {badge.rarity === "epic" && "Эпический"}
              {badge.rarity === "legendary" && "Легендарный"}
            </BadgeUI>
          </div>
        </CardHeader>
        <CardContent className="relative space-y-3">
          <CardDescription className="text-center text-sm text-muted-foreground">
            {badge.description}
          </CardDescription>
          <div className="bg-muted/50 rounded-lg p-3 border border-border/50">
            <p className="text-xs text-muted-foreground text-center">
              <span className="font-semibold">Требование:</span> {badge.requirement}
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

interface ProgressCardProps {
  progress: UserProgress;
}

export function ProgressCard({ progress }: ProgressCardProps) {
  const progressPercentage = Math.min(
    (progress.totalPoints / (progress.totalPoints + progress.pointsToNextLevel)) * 100,
    100
  );

  return (
    <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/30 shadow-[0_8px_30px_-6px_color-mix(in_srgb,var(--primary)_15%,transparent)]">
      <CardHeader className="space-y-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl font-bold text-foreground">
            Уровень {progress.level}
          </CardTitle>
          <div className="flex items-center gap-2 bg-primary/20 px-4 py-2 rounded-full border border-primary/50">
            <Award className="h-5 w-5 text-primary" />
            <span className="font-bold text-lg text-primary">
              {progress.totalPoints}
            </span>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Прогресс до следующего уровня</span>
            <span className="font-semibold text-foreground">
              {progress.pointsToNextLevel} очков
            </span>
          </div>
          <Progress value={progressPercentage} className="h-3" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-card/50 rounded-lg p-4 border border-border/50 space-y-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Target className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">
                Точность
              </span>
            </div>
            <p className="text-2xl font-bold text-foreground">
              {progress.statistics.averageAccuracy}%
            </p>
          </div>
          <div className="bg-card/50 rounded-lg p-4 border border-border/50 space-y-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">
                Серия дней
              </span>
            </div>
            <p className="text-2xl font-bold text-foreground">
              {progress.streakDays}
            </p>
          </div>
        </div>
        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Статистика
          </p>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-muted/50 rounded-lg p-3 border border-border/50">
              <p className="text-lg font-bold text-foreground">
                {progress.statistics.totalExercises}
              </p>
              <p className="text-xs text-muted-foreground">Заданий</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-3 border border-border/50">
              <p className="text-lg font-bold text-chart-3">
                {progress.statistics.correctAnswers}
              </p>
              <p className="text-xs text-muted-foreground">Правильно</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-3 border border-border/50">
              <p className="text-lg font-bold text-foreground">
                {progress.earnedBadges.length}
              </p>
              <p className="text-xs text-muted-foreground">Бейджей</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
