import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Check, X, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ExerciseProps {
  data: any;
  onComplete: (correct: boolean) => void;
}

export function MatchPairExercise({ data, onComplete }: ExerciseProps) {
  const [selected, setSelected] = useState<{ left?: number; right?: number }>({});
  const [matched, setMatched] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);

  const pairs = data.pairs || [];
  const leftItems = pairs.map((p: any, i: number) => ({ id: i, text: p.english }));
  const rightItems = pairs.map((p: any, i: number) => ({ id: i, text: p.russian })).sort(() => Math.random() - 0.5);

  const handleSelect = (side: 'left' | 'right', id: number) => {
    if (matched.includes(id)) return;

    const newSelected = { ...selected, [side]: id };
    setSelected(newSelected);

    if (newSelected.left !== undefined && newSelected.right !== undefined) {
      const leftId = newSelected.left;
      const rightId = newSelected.right;

      if (leftId === rightId) {
        setFeedback('correct');
        setMatched([...matched, leftId]);
        setTimeout(() => {
          setSelected({});
          setFeedback(null);
          if (matched.length + 1 === pairs.length) {
            onComplete(true);
          }
        }, 800);
      } else {
        setFeedback('incorrect');
        setTimeout(() => {
          setSelected({});
          setFeedback(null);
        }, 800);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-8">
        <div className="space-y-3">
          {leftItems.map((item: any) => (
            <motion.div
              key={item.id}
              whileHover={{ scale: matched.includes(item.id) ? 1 : 1.02 }}
              whileTap={{ scale: matched.includes(item.id) ? 1 : 0.98 }}
            >
              <Card
                className={cn(
                  'p-4 cursor-pointer transition-all duration-200',
                  matched.includes(item.id) && 'opacity-40 cursor-not-allowed bg-primary/20',
                  selected.left === item.id && 'ring-2 ring-primary shadow-lg shadow-primary/50',
                  !matched.includes(item.id) && 'hover:shadow-lg hover:shadow-primary/30'
                )}
                onClick={() => !matched.includes(item.id) && handleSelect('left', item.id)}
              >
                <p className="text-center font-semibold">{item.text}</p>
              </Card>
            </motion.div>
          ))}
        </div>
        <div className="space-y-3">
          {rightItems.map((item: any) => (
            <motion.div
              key={item.id}
              whileHover={{ scale: matched.includes(item.id) ? 1 : 1.02 }}
              whileTap={{ scale: matched.includes(item.id) ? 1 : 0.98 }}
            >
              <Card
                className={cn(
                  'p-4 cursor-pointer transition-all duration-200',
                  matched.includes(item.id) && 'opacity-40 cursor-not-allowed bg-primary/20',
                  selected.right === item.id && 'ring-2 ring-primary shadow-lg shadow-primary/50',
                  !matched.includes(item.id) && 'hover:shadow-lg hover:shadow-primary/30'
                )}
                onClick={() => !matched.includes(item.id) && handleSelect('right', item.id)}
              >
                <p className="text-center font-semibold">{item.text}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={cn(
              'flex items-center justify-center gap-2 p-4 rounded-lg',
              feedback === 'correct' ? 'bg-primary/20 text-primary' : 'bg-destructive/20 text-destructive'
            )}
          >
            {feedback === 'correct' ? <Check className="w-6 h-6" /> : <X className="w-6 h-6" />}
            <span className="font-semibold">{feedback === 'correct' ? 'Правильно!' : 'Попробуй еще раз'}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function ChatRepairExercise({ data, onComplete }: ExerciseProps) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const sentence = data.sentence || '';
  const options = data.options || [];
  const correctIndex = data.correctIndex || 0;

  const handleSelect = (index: number) => {
    setSelectedOption(index);
    setShowFeedback(true);
    const isCorrect = index === correctIndex;
    setTimeout(() => {
      onComplete(isCorrect);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-muted/50">
        <p className="text-lg text-center font-mono">{sentence}</p>
      </Card>
      <div className="space-y-3">
        {options.map((option: string, index: number) => (
          <motion.div
            key={index}
            whileHover={{ scale: selectedOption === null ? 1.02 : 1 }}
            whileTap={{ scale: selectedOption === null ? 0.98 : 1 }}
          >
            <Button
              variant="outline"
              className={cn(
                'w-full p-6 text-left justify-start h-auto transition-all duration-200',
                selectedOption === index && showFeedback && index === correctIndex && 'bg-primary/20 border-primary',
                selectedOption === index && showFeedback && index !== correctIndex && 'bg-destructive/20 border-destructive',
                selectedOption === null && 'hover:shadow-lg hover:shadow-primary/30'
              )}
              onClick={() => selectedOption === null && handleSelect(index)}
              disabled={selectedOption !== null}
            >
              <span className="flex-1">{option}</span>
              {selectedOption === index && showFeedback && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  {index === correctIndex ? <Check className="w-5 h-5 text-primary" /> : <X className="w-5 h-5 text-destructive" />}
                </motion.div>
              )}
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export function WordBuilderExercise({ data, onComplete }: ExerciseProps) {
  const targetWord = data.word || '';
  const [letters, setLetters] = useState<string[]>([]);
  const [builtWord, setBuiltWord] = useState<string[]>([]);
  const [showFeedback, setShowFeedback] = useState(false);

  useEffect(() => {
    const shuffled = targetWord.split('').sort(() => Math.random() - 0.5);
    setLetters(shuffled);
  }, [targetWord]);

  const handleLetterClick = (letter: string, index: number) => {
    setBuiltWord([...builtWord, letter]);
    setLetters(letters.filter((_, i) => i !== index));
  };

  const handleRemoveLetter = (index: number) => {
    const letter = builtWord[index];
    setLetters([...letters, letter]);
    setBuiltWord(builtWord.filter((_, i) => i !== index));
  };

  const handleCheck = () => {
    const isCorrect = builtWord.join('').toLowerCase() === targetWord.toLowerCase();
    setShowFeedback(true);
    setTimeout(() => {
      onComplete(isCorrect);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <p className="text-muted-foreground mb-2">Собери слово:</p>
        <p className="text-2xl font-bold">{data.hint || 'Подсказка'}</p>
      </div>
      <Card className="p-6 min-h-[80px] flex items-center justify-center gap-2 flex-wrap">
        {builtWord.length === 0 ? (
          <span className="text-muted-foreground">Нажми на буквы ниже</span>
        ) : (
          builtWord.map((letter, index) => (
            <motion.div
              key={index}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Button
                variant="outline"
                className="w-12 h-12 text-xl font-bold"
                onClick={() => handleRemoveLetter(index)}
              >
                {letter}
              </Button>
            </motion.div>
          ))
        )}
      </Card>
      <div className="flex flex-wrap gap-2 justify-center">
        {letters.map((letter, index) => (
          <motion.div
            key={index}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <Button
              variant="secondary"
              className="w-12 h-12 text-xl font-bold"
              onClick={() => handleLetterClick(letter, index)}
            >
              {letter}
            </Button>
          </motion.div>
        ))}
      </div>
      {builtWord.length === targetWord.length && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Button
            className="w-full"
            size="lg"
            onClick={handleCheck}
            disabled={showFeedback}
          >
            Проверить
          </Button>
        </motion.div>
      )}
      <AnimatePresence>
        {showFeedback && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={cn(
              'flex items-center justify-center gap-2 p-4 rounded-lg',
              builtWord.join('').toLowerCase() === targetWord.toLowerCase()
                ? 'bg-primary/20 text-primary'
                : 'bg-destructive/20 text-destructive'
            )}
          >
            {builtWord.join('').toLowerCase() === targetWord.toLowerCase() ? (
              <><Check className="w-6 h-6" /><span className="font-semibold">Отлично!</span></>
            ) : (
              <><X className="w-6 h-6" /><span className="font-semibold">Неправильно</span></>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function FillBlanksExercise({ data, onComplete }: ExerciseProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const sentence = data.sentence || '';
  const options = data.options || [];
  const correctAnswer = data.correctAnswer || '';

  const parts = sentence.split('____');

  const handleSelect = (option: string) => {
    setSelectedOption(option);
    setShowFeedback(true);
    const isCorrect = option.toLowerCase() === correctAnswer.toLowerCase();
    setTimeout(() => {
      onComplete(isCorrect);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-muted/50">
        <p className="text-lg text-center font-mono">
          {parts[0]}
          <span className={cn(
            'inline-block min-w-[120px] mx-2 px-4 py-1 rounded border-2 border-dashed',
            selectedOption && showFeedback && selectedOption.toLowerCase() === correctAnswer.toLowerCase() && 'border-primary bg-primary/20',
            selectedOption && showFeedback && selectedOption.toLowerCase() !== correctAnswer.toLowerCase() && 'border-destructive bg-destructive/20',
            !selectedOption && 'border-muted-foreground'
          )}>
            {selectedOption || '____'}
          </span>
          {parts[1]}
        </p>
      </Card>
      <div className="grid grid-cols-2 gap-3">
        {options.map((option: string, index: number) => (
          <motion.div
            key={index}
            whileHover={{ scale: selectedOption === null ? 1.02 : 1 }}
            whileTap={{ scale: selectedOption === null ? 0.98 : 1 }}
          >
            <Button
              variant="outline"
              className={cn(
                'w-full p-4 h-auto transition-all duration-200',
                selectedOption === option && showFeedback && option.toLowerCase() === correctAnswer.toLowerCase() && 'bg-primary/20 border-primary',
                selectedOption === option && showFeedback && option.toLowerCase() !== correctAnswer.toLowerCase() && 'bg-destructive/20 border-destructive',
                selectedOption === null && 'hover:shadow-lg hover:shadow-primary/30'
              )}
              onClick={() => selectedOption === null && handleSelect(option)}
              disabled={selectedOption !== null}
            >
              {option}
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export function ImageQuizExercise({ data, onComplete }: ExerciseProps) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const imageUrl = data.imageUrl || '';
  const question = data.question || '';
  const options = data.options || [];
  const correctIndex = data.correctIndex || 0;

  const handleSelect = (index: number) => {
    setSelectedOption(index);
    setShowFeedback(true);
    const isCorrect = index === correctIndex;
    setTimeout(() => {
      onComplete(isCorrect);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-muted/50">
        <div className="aspect-video bg-muted rounded-lg mb-4 flex items-center justify-center overflow-hidden">
          {imageUrl ? (
            <img src={imageUrl} alt="Quiz" className="w-full h-full object-cover" />
          ) : (
            <span className="text-muted-foreground">Изображение</span>
          )}
        </div>
        <p className="text-lg text-center font-semibold">{question}</p>
      </Card>
      <div className="grid grid-cols-2 gap-3">
        {options.map((option: string, index: number) => (
          <motion.div
            key={index}
            whileHover={{ scale: selectedOption === null ? 1.02 : 1 }}
            whileTap={{ scale: selectedOption === null ? 0.98 : 1 }}
          >
            <Button
              variant="outline"
              className={cn(
                'w-full p-4 h-auto transition-all duration-200',
                selectedOption === index && showFeedback && index === correctIndex && 'bg-primary/20 border-primary',
                selectedOption === index && showFeedback && index !== correctIndex && 'bg-destructive/20 border-destructive',
                selectedOption === null && 'hover:shadow-lg hover:shadow-primary/30'
              )}
              onClick={() => selectedOption === null && handleSelect(index)}
              disabled={selectedOption !== null}
            >
              <span className="flex-1">{option}</span>
              {selectedOption === index && showFeedback && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  {index === correctIndex ? <Check className="w-5 h-5 text-primary" /> : <X className="w-5 h-5 text-destructive" />}
                </motion.div>
              )}
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export function TrueFalseExercise({ data, onComplete }: ExerciseProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<boolean | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const statement = data.statement || '';
  const correctAnswer = data.correctAnswer || false;

  const handleSelect = (answer: boolean) => {
    setSelectedAnswer(answer);
    setShowFeedback(true);
    const isCorrect = answer === correctAnswer;
    setTimeout(() => {
      onComplete(isCorrect);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="p-8 bg-muted/50">
        <p className="text-xl text-center font-semibold">{statement}</p>
      </Card>
      <div className="grid grid-cols-2 gap-4">
        <motion.div
          whileHover={{ scale: selectedAnswer === null ? 1.05 : 1 }}
          whileTap={{ scale: selectedAnswer === null ? 0.95 : 1 }}
        >
          <Button
            variant="outline"
            size="lg"
            className={cn(
              'w-full h-24 text-xl font-bold transition-all duration-200',
              selectedAnswer === true && showFeedback && correctAnswer === true && 'bg-primary/20 border-primary',
              selectedAnswer === true && showFeedback && correctAnswer === false && 'bg-destructive/20 border-destructive',
              selectedAnswer === null && 'hover:shadow-lg hover:shadow-primary/30'
            )}
            onClick={() => selectedAnswer === null && handleSelect(true)}
            disabled={selectedAnswer !== null}
          >
            <div className="flex flex-col items-center gap-2">
              {selectedAnswer === true && showFeedback && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  {correctAnswer === true ? <Check className="w-8 h-8 text-primary" /> : <X className="w-8 h-8 text-destructive" />}
                </motion.div>
              )}
              <span>TRUE</span>
            </div>
          </Button>
        </motion.div>
        <motion.div
          whileHover={{ scale: selectedAnswer === null ? 1.05 : 1 }}
          whileTap={{ scale: selectedAnswer === null ? 0.95 : 1 }}
        >
          <Button
            variant="outline"
            size="lg"
            className={cn(
              'w-full h-24 text-xl font-bold transition-all duration-200',
              selectedAnswer === false && showFeedback && correctAnswer === false && 'bg-primary/20 border-primary',
              selectedAnswer === false && showFeedback && correctAnswer === true && 'bg-destructive/20 border-destructive',
              selectedAnswer === null && 'hover:shadow-lg hover:shadow-primary/30'
            )}
            onClick={() => selectedAnswer === null && handleSelect(false)}
            disabled={selectedAnswer !== null}
          >
            <div className="flex flex-col items-center gap-2">
              {selectedAnswer === false && showFeedback && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  {correctAnswer === false ? <Check className="w-8 h-8 text-primary" /> : <X className="w-8 h-8 text-destructive" />}
                </motion.div>
              )}
              <span>FALSE</span>
            </div>
          </Button>
        </motion.div>
      </div>
      <AnimatePresence>
        {showFeedback && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="flex justify-center"
          >
            {selectedAnswer === correctAnswer && (
              <motion.div
                initial={{ rotate: 0 }}
                animate={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                <Sparkles className="w-12 h-12 text-primary" />
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}