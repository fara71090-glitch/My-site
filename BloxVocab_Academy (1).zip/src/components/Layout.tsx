import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Book, Dumbbell, Trophy, Calendar, User, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { ROUTE_PATHS } from '@/lib/index';
import { useGameProgress } from '@/hooks/useGameProgress';
import { SiX, SiFacebook, SiGithub, SiDiscord } from 'react-icons/si';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { progress } = useGameProgress();

  const navItems = [
    { path: ROUTE_PATHS.DICTIONARY, icon: Book, label: 'Словарь' },
    { path: ROUTE_PATHS.TRAINING, icon: Dumbbell, label: 'Тренировки' },
    { path: ROUTE_PATHS.QUIZ, icon: Trophy, label: 'Квизы' },
    { path: ROUTE_PATHS.DAILY, icon: Calendar, label: 'Челлендж' },
  ];

  const levelProgress = ((progress.totalPoints % 1000) / 1000) * 100;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-primary/20 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <NavLink
              to={ROUTE_PATHS.HOME}
              className="flex items-center gap-3 transition-all duration-200 hover:scale-105"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/50">
                <Book className="h-6 w-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold tracking-tight">
                BloxVocab <span className="text-primary">Academy</span>
              </span>
            </NavLink>

            <nav className="hidden items-center gap-2 md:flex">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `group relative flex items-center gap-2 rounded-lg px-4 py-2 font-medium transition-all duration-200 hover:scale-105 ${
                      isActive
                        ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/50'
                        : 'text-muted-foreground hover:bg-primary/10 hover:text-foreground'
                    }`
                  }
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                  <div className="absolute inset-0 rounded-lg opacity-0 transition-opacity duration-200 group-hover:opacity-100" style={{ boxShadow: '0 0 20px rgba(0, 162, 255, 0.3)' }} />
                </NavLink>
              ))}
            </nav>

            <div className="flex items-center gap-4">
              <NavLink
                to={ROUTE_PATHS.PROFILE}
                className="hidden items-center gap-2 rounded-lg border border-primary/20 bg-card px-4 py-2 font-medium transition-all duration-200 hover:scale-105 hover:border-primary/50 hover:bg-primary/10 md:flex"
              >
                <User className="h-5 w-5" />
                <span>Профиль</span>
              </NavLink>

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-card transition-all duration-200 hover:scale-105 hover:border-primary/50 hover:bg-primary/10 md:hidden"
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="border-t border-primary/20 bg-background/95 backdrop-blur md:hidden"
          >
            <nav className="container mx-auto flex flex-col gap-2 px-4 py-4">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 rounded-lg px-4 py-3 font-medium transition-all duration-200 ${
                      isActive
                        ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/50'
                        : 'text-muted-foreground hover:bg-primary/10 hover:text-foreground'
                    }`
                  }
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </NavLink>
              ))}
              <NavLink
                to={ROUTE_PATHS.PROFILE}
                onClick={() => setMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-lg px-4 py-3 font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/50'
                      : 'text-muted-foreground hover:bg-primary/10 hover:text-foreground'
                  }`
                }
              >
                <User className="h-5 w-5" />
                <span>Профиль</span>
              </NavLink>
            </nav>
          </motion.div>
        )}
      </header>

      <div className="flex pt-16">
        <aside className="fixed left-0 top-16 hidden h-[calc(100vh-4rem)] w-64 border-r border-primary/20 bg-card/50 p-6 lg:block">
          <div className="space-y-6">
            <div className="rounded-xl border border-primary/20 bg-gradient-to-br from-primary/10 to-accent/10 p-4 shadow-lg">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-sm font-medium text-muted-foreground">Уровень</span>
                <span className="text-2xl font-bold text-primary">{progress.level}</span>
              </div>
              <div className="relative h-3 overflow-hidden rounded-full bg-muted">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${levelProgress}%` }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                  className="h-full rounded-full bg-gradient-to-r from-primary to-accent shadow-lg shadow-primary/50"
                />
              </div>
              <div className="mt-2 text-xs text-muted-foreground">
                {progress.pointsToNextLevel} очков до следующего уровня
              </div>
            </div>

            <div className="rounded-xl border border-primary/20 bg-card p-4 shadow-lg">
              <div className="mb-3 flex items-center gap-2">
                <Trophy className="h-5 w-5 text-primary" />
                <span className="font-semibold">Очки</span>
              </div>
              <div className="text-3xl font-bold text-primary">{progress.totalPoints.toLocaleString()}</div>
            </div>

            <div className="rounded-xl border border-primary/20 bg-card p-4 shadow-lg">
              <div className="mb-3 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                <span className="font-semibold">Серия дней</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-primary">{progress.streakDays}</span>
                <span className="text-sm text-muted-foreground">дней подряд</span>
              </div>
            </div>

            <div className="rounded-xl border border-primary/20 bg-card p-4 shadow-lg">
              <div className="mb-3 flex items-center justify-between">
                <span className="font-semibold">Бейджи</span>
                <span className="text-sm text-muted-foreground">{progress.earnedBadges.length}</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {progress.earnedBadges.slice(0, 6).map((badgeId) => (
                  <div
                    key={badgeId}
                    className="flex aspect-square items-center justify-center rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 shadow-lg shadow-primary/30 transition-all duration-200 hover:scale-110"
                  >
                    <Trophy className="h-6 w-6 text-primary" />
                  </div>
                ))}
                {progress.earnedBadges.length === 0 && (
                  <div className="col-span-3 py-4 text-center text-sm text-muted-foreground">
                    Пока нет бейджей
                  </div>
                )}
              </div>
            </div>
          </div>
        </aside>

        <main className="min-h-[calc(100vh-4rem)] flex-1 lg:ml-64">{children}</main>
      </div>

      <footer className="border-t border-primary/20 bg-card/50 lg:ml-64">
        <div className="container mx-auto px-4 py-8">
          <div className="grid gap-8 md:grid-cols-3">
            <div>
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/50">
                  <Book className="h-6 w-6 text-primary-foreground" />
                </div>
                <span className="text-lg font-bold">
                  BloxVocab <span className="text-primary">Academy</span>
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                Изучай английский через игровой опыт Roblox. Геймификация обучения для детей 10+.
              </p>
            </div>

            <div>
              <h3 className="mb-4 font-semibold">Навигация</h3>
              <ul className="space-y-2 text-sm">
                {navItems.map((item) => (
                  <li key={item.path}>
                    <NavLink
                      to={item.path}
                      className="text-muted-foreground transition-colors duration-200 hover:text-primary"
                    >
                      {item.label}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="mb-4 font-semibold">Социальные сети</h3>
              <div className="flex gap-3">
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-card transition-all duration-200 hover:scale-110 hover:border-primary/50 hover:bg-primary/10"
                >
                  <SiX className="h-5 w-5" />
                </a>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-card transition-all duration-200 hover:scale-110 hover:border-primary/50 hover:bg-primary/10"
                >
                  <SiFacebook className="h-5 w-5" />
                </a>
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-card transition-all duration-200 hover:scale-110 hover:border-primary/50 hover:bg-primary/10"
                >
                  <SiGithub className="h-5 w-5" />
                </a>
                <a
                  href="https://discord.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-lg border border-primary/20 bg-card transition-all duration-200 hover:scale-110 hover:border-primary/50 hover:bg-primary/10"
                >
                  <SiDiscord className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>

          <div className="mt-8 border-t border-primary/20 pt-6 text-center text-sm text-muted-foreground">
            <p>© 2026 BloxVocab Academy. Все права защищены.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
