import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/lib/index";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { Trophy, Clock, RotateCcw, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

interface QuizQuestionProps {
  question: {
    id: string;
    question: string;
    options: string[];
    correctAnswer: string;
    explanation?: string;
  };
  onAnswer: (answer: string) => void;
}

export function QuizQuestion({ question, onAnswer }: QuizQuestionProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const handleAnswer = (answer: string) => {
    setSelectedAnswer(answer);
    setShowFeedback(true);
    
    setTimeout(() => {
      onAnswer(answer);
      setSelectedAnswer(null);
      setShowFeedback(false);
    }, 1500);
  };

  const isCorrect = selectedAnswer === question.correctAnswer;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="w-full max-w-3xl mx-auto"
    >
      <Card className="p-8 bg-card/80 backdrop-blur border-2 border-primary/20 shadow-[0_8px_30px_-6px_color-mix(in_srgb,var(--primary)_15%,transparent)]">
        <h3 className="text-2xl font-bold text-foreground mb-8 text-center">
          {question.question}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {question.options.map((option, index) => {
            const isSelected = selectedAnswer === option;
            const isCorrectOption = option === question.correctAnswer;
            const showCorrect = showFeedback && isCorrectOption;
            const showIncorrect = showFeedback && isSelected && !isCorrect;

            return (
              <motion.button
                key={index}
                onClick={() => !showFeedback && handleAnswer(option)}
                disabled={showFeedback}
                whileHover={!showFeedback ? { scale: 1.02 } : {}}
                whileTap={!showFeedback ? { scale: 0.98 } : {}}
                className={`
                  relative p-6 rounded-xl text-left font-medium transition-all duration-300
                  ${
                    showCorrect
                      ? "bg-green-500/20 border-2 border-green-500 text-green-400"
                      : showIncorrect
                      ? "bg-red-500/20 border-2 border-red-500 text-red-400"
                      : isSelected
                      ? "bg-primary/20 border-2 border-primary text-primary"
                      : "bg-secondary/50 border-2 border-border hover:border-primary/50 text-foreground"
                  }
                  shadow-[0_4px_12px_color-mix(in_srgb,var(--primary)_35%,transparent),inset_0_1px_0_rgba(255,255,255,0.1),inset_0_-1px_0_rgba(0,0,0,0.1)]
                `}
              >
                <span className="text-lg">{option}</span>
                {showCorrect && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-2 right-2"
                  >
                    <Sparkles className="w-6 h-6 text-green-400" />
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </div>

        <AnimatePresence>
          {showFeedback && question.explanation && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-6 p-4 rounded-lg bg-muted/50 border border-border"
            >
              <p className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">Объяснение:</span>{" "}
                {question.explanation}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      {showFeedback && isCorrect && <ConfettiEffect />}
    </motion.div>
  );
}

interface QuizResultsProps {
  score: number;
  total: number;
  badges: Badge[];
}

export function QuizResults({ score, total, badges }: QuizResultsProps) {
  const percentage = Math.round((score / total) * 100);
  const isPerfect = score === total;
  const isGood = percentage >= 70;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="w-full max-w-2xl mx-auto"
    >
      <Card className="p-8 bg-card/80 backdrop-blur border-2 border-primary/20 shadow-[0_8px_30px_-6px_color-mix(in_srgb,var(--primary)_15%,transparent)]">
        <div className="text-center space-y-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 400, damping: 25 }}
          >
            <Trophy
              className={`w-24 h-24 mx-auto ${
                isPerfect
                  ? "text-yellow-400"
                  : isGood
                  ? "text-primary"
                  : "text-muted-foreground"
              }`}
            />
          </motion.div>

          <div>
            <h2 className="text-4xl font-bold text-foreground mb-2">
              {isPerfect ? "Идеально!" : isGood ? "Отлично!" : "Хорошая попытка!"}
            </h2>
            <p className="text-muted-foreground">
              {isPerfect
                ? "Ты ответил правильно на все вопросы!"
                : isGood
                ? "Ты показал отличный результат!"
                : "Продолжай тренироваться!"}
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-center gap-4">
              <div className="text-center">
                <div className="text-5xl font-bold text-primary">{score}</div>
                <div className="text-sm text-muted-foreground">из {total}</div>
              </div>
              <div className="text-6xl text-muted-foreground">/</div>
              <div className="text-center">
                <div className="text-5xl font-bold text-accent">{percentage}%</div>
                <div className="text-sm text-muted-foreground">точность</div>
              </div>
            </div>

            <Progress value={percentage} className="h-3" />
          </div>

          {badges.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-semibold text-foreground">
                Заработанные бейджи
              </h3>
              <div className="flex flex-wrap justify-center gap-4">
                {badges.map((badge, index) => (
                  <motion.div
                    key={badge.id}
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{
                      delay: 0.6 + index * 0.1,
                      type: "spring",
                      stiffness: 500,
                      damping: 25,
                    }}
                    className="flex flex-col items-center gap-2 p-4 rounded-lg bg-primary/10 border border-primary/30"
                  >
                    <div className="text-4xl">{badge.icon}</div>
                    <div className="text-sm font-medium text-foreground">
                      {badge.name}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          <Button
            size="lg"
            className="mt-6 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 shadow-[0_4px_12px_color-mix(in_srgb,var(--primary)_35%,transparent),inset_0_1px_0_rgba(255,255,255,0.1),inset_0_-1px_0_rgba(0,0,0,0.1)]"
            onClick={() => window.location.reload()}
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            Попробовать снова
          </Button>
        </div>
      </Card>

      {isPerfect && <ConfettiEffect />}
    </motion.div>
  );
}

interface QuizTimerProps {
  seconds: number;
  onTimeout: () => void;
}

export function QuizTimer({ seconds, onTimeout }: QuizTimerProps) {
  const [timeLeft, setTimeLeft] = useState(seconds);

  useEffect(() => {
    if (timeLeft <= 0) {
      onTimeout();
      return;
    }

    const timer = setTimeout(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [timeLeft, onTimeout]);

  const minutes = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;
  const isLowTime = timeLeft <= 30;
  const isCritical = timeLeft <= 10;

  return (
    <motion.div
      animate={isCritical ? { scale: [1, 1.05, 1] } : {}}
      transition={{ repeat: Infinity, duration: 1 }}
      className="flex items-center gap-3 px-6 py-3 rounded-full bg-card/80 backdrop-blur border-2 border-primary/20 shadow-[0_4px_12px_color-mix(in_srgb,var(--primary)_35%,transparent),inset_0_1px_0_rgba(255,255,255,0.1),inset_0_-1px_0_rgba(0,0,0,0.1)]"
    >
      <Clock
        className={`w-6 h-6 ${
          isCritical
            ? "text-red-500"
            : isLowTime
            ? "text-yellow-500"
            : "text-primary"
        }`}
      />
      <span
        className={`text-2xl font-bold tabular-nums ${
          isCritical
            ? "text-red-500"
            : isLowTime
            ? "text-yellow-500"
            : "text-primary"
        }`}
      >
        {String(minutes).padStart(2, "0")}:{String(secs).padStart(2, "0")}
      </span>
    </motion.div>
  );
}

export function ConfettiEffect() {
  const colors = ["#00A2FF", "#FF00FF", "#00FF00", "#FFD700", "#FF6B6B"];
  const confettiCount = 50;

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {Array.from({ length: confettiCount }).map((_, i) => {
        const randomX = Math.random() * 100;
        const randomDelay = Math.random() * 0.5;
        const randomDuration = 2 + Math.random() * 2;
        const randomRotation = Math.random() * 360;
        const randomColor = colors[Math.floor(Math.random() * colors.length)];

        return (
          <motion.div
            key={i}
            initial={{
              x: `${randomX}vw`,
              y: -20,
              rotate: 0,
              opacity: 1,
            }}
            animate={{
              y: "100vh",
              rotate: randomRotation,
              opacity: 0,
            }}
            transition={{
              duration: randomDuration,
              delay: randomDelay,
              ease: "linear",
            }}
            style={{
              position: "absolute",
              width: "10px",
              height: "10px",
              backgroundColor: randomColor,
              borderRadius: "2px",
            }}
          />
        );
      })}
    </div>
  );
}
