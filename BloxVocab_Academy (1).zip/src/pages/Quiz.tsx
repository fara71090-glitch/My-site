import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Layout } from '@/components/Layout';
import { QuizQuestion, QuizResults, QuizTimer, ConfettiEffect } from '@/components/QuizComponents';
import { quizzesData, badgesData } from '@/data/index';
import { useGameProgress } from '@/hooks/useGameProgress';
import type { Quiz, QuizQuestion as QuizQuestionType, Badge } from '@/lib/index';
import { IMAGES } from '@/assets/images';
import { Trophy, Clock, Target, Zap, ChevronRight, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge as BadgeUI } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

type QuizState = 'selection' | 'active' | 'results';

const difficultyColors = {
  beginner: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  intermediate: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  advanced: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
};

const difficultyLabels = {
  beginner: 'Начальный',
  intermediate: 'Средний',
  advanced: 'Продвинутый',
};

export default function Quiz() {
  const { progress, addPoints, unlockBadge, completeQuiz, isQuizCompleted } = useGameProgress();
  const [quizState, setQuizState] = useState<QuizState>('selection');
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    if (quizState === 'active' && timeRemaining > 0) {
      const timer = setTimeout(() => {
        setTimeRemaining(timeRemaining - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (quizState === 'active' && timeRemaining === 0) {
      handleQuizComplete();
    }
  }, [quizState, timeRemaining]);

  const startQuiz = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setTimeRemaining(quiz.timeLimit);
    setQuizState('active');
  };

  const handleAnswer = (answer: string) => {
    const newAnswers = [...answers, answer];
    setAnswers(newAnswers);

    if (selectedQuiz && currentQuestionIndex < selectedQuiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      handleQuizComplete(newAnswers);
    }
  };

  const handleQuizComplete = (finalAnswers?: string[]) => {
    if (!selectedQuiz) return;

    const answersToCheck = finalAnswers || answers;
    const score = answersToCheck.reduce((acc, answer, index) => {
      return answer === selectedQuiz.questions[index].correctAnswer ? acc + 1 : acc;
    }, 0);

    const percentage = (score / selectedQuiz.questions.length) * 100;

    addPoints(selectedQuiz.reward.points);
    completeQuiz(selectedQuiz.id, score, selectedQuiz.questions.length);

    if (selectedQuiz.reward.badgeId) {
      const badgeRequirements: Record<string, number> = {
        'badge-1': 80,
        'badge-2': 90,
        'badge-3': 95,
      };

      const requiredPercentage = badgeRequirements[selectedQuiz.reward.badgeId] || 100;
      if (percentage >= requiredPercentage) {
        unlockBadge(selectedQuiz.reward.badgeId);
      }
    }

    if (percentage >= 90) {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 5000);
    }

    setQuizState('results');
  };

  const handleRetry = () => {
    if (selectedQuiz) {
      startQuiz(selectedQuiz);
    }
  };

  const handleBackToSelection = () => {
    setQuizState('selection');
    setSelectedQuiz(null);
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setTimeRemaining(0);
  };

  const getEarnedBadges = (): Badge[] => {
    if (!selectedQuiz || !selectedQuiz.reward.badgeId) return [];

    const score = answers.reduce((acc, answer, index) => {
      return answer === selectedQuiz.questions[index].correctAnswer ? acc + 1 : acc;
    }, 0);
    const percentage = (score / selectedQuiz.questions.length) * 100;

    const badgeRequirements: Record<string, number> = {
      'badge-1': 80,
      'badge-2': 90,
      'badge-3': 95,
    };

    const requiredPercentage = badgeRequirements[selectedQuiz.reward.badgeId] || 100;
    if (percentage >= requiredPercentage) {
      const badge = badgesData.find(b => b.id === selectedQuiz.reward.badgeId);
      return badge ? [badge] : [];
    }
    return [];
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={IMAGES.QUIZ_BG_4}
            alt=""
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background/90" />
        </div>

        <div className="relative z-10 container mx-auto px-4 py-12">
          <AnimatePresence mode="wait">
            {quizState === 'selection' && (
              <motion.div
                key="selection"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <div className="text-center mb-12">
                  <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
                  >
                    <Trophy className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-primary">Квизы и Битвы</span>
                  </motion.div>
                  <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                    Проверь свои знания
                  </h1>
                  <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                    Выбери квиз и докажи, что ты настоящий мастер английского языка Roblox
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
                  {quizzesData.map((quiz, index) => {
                    const completed = isQuizCompleted(quiz.id);
                    return (
                      <motion.div
                        key={quiz.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <Card className="group relative overflow-hidden border-2 border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,162,255,0.3)]">
                          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                          
                          <div className="relative p-6">
                            <div className="flex items-start justify-between mb-4">
                              <BadgeUI className={`${difficultyColors[quiz.difficulty]} border`}>
                                {difficultyLabels[quiz.difficulty]}
                              </BadgeUI>
                              {completed && (
                                <div className="flex items-center gap-1 text-emerald-400">
                                  <Trophy className="w-4 h-4" />
                                  <span className="text-xs font-medium">Пройден</span>
                                </div>
                              )}
                            </div>

                            <h3 className="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">
                              {quiz.title}
                            </h3>
                            <p className="text-muted-foreground mb-6">
                              {quiz.description}
                            </p>

                            <div className="space-y-3 mb-6">
                              <div className="flex items-center gap-2 text-sm">
                                <Clock className="w-4 h-4 text-primary" />
                                <span className="text-muted-foreground">
                                  Время: <span className="text-foreground font-medium">{Math.floor(quiz.timeLimit / 60)} минут</span>
                                </span>
                              </div>
                              <div className="flex items-center gap-2 text-sm">
                                <Target className="w-4 h-4 text-accent" />
                                <span className="text-muted-foreground">
                                  Вопросов: <span className="text-foreground font-medium">{quiz.questions.length}</span>
                                </span>
                              </div>
                              <div className="flex items-center gap-2 text-sm">
                                <Zap className="w-4 h-4 text-amber-400" />
                                <span className="text-muted-foreground">
                                  Награда: <span className="text-foreground font-medium">{quiz.reward.points} очков</span>
                                </span>
                              </div>
                            </div>

                            <Button
                              onClick={() => startQuiz(quiz)}
                              className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white font-semibold shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all duration-300"
                            >
                              {completed ? 'Пройти снова' : 'Начать квиз'}
                              <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                            </Button>
                          </div>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {quizState === 'active' && selectedQuiz && (
              <motion.div
                key="active"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="max-w-4xl mx-auto"
              >
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-3xl font-bold mb-2">{selectedQuiz.title}</h2>
                      <p className="text-muted-foreground">
                        Вопрос {currentQuestionIndex + 1} из {selectedQuiz.questions.length}
                      </p>
                    </div>
                    <QuizTimer seconds={timeRemaining} onTimeout={handleQuizComplete} />
                  </div>
                  <Progress
                    value={((currentQuestionIndex + 1) / selectedQuiz.questions.length) * 100}
                    className="h-2"
                  />
                </div>

                <QuizQuestion
                  question={selectedQuiz.questions[currentQuestionIndex]}
                  onAnswer={handleAnswer}
                />
              </motion.div>
            )}

            {quizState === 'results' && selectedQuiz && (
              <motion.div
                key="results"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="max-w-4xl mx-auto"
              >
                <QuizResults
                  score={answers.reduce((acc, answer, index) => {
                    return answer === selectedQuiz.questions[index].correctAnswer ? acc + 1 : acc;
                  }, 0)}
                  total={selectedQuiz.questions.length}
                  badges={getEarnedBadges()}
                />

                <div className="flex gap-4 justify-center mt-8">
                  <Button
                    onClick={handleRetry}
                    variant="outline"
                    size="lg"
                    className="border-primary/30 hover:border-primary hover:bg-primary/10"
                  >
                    <RotateCcw className="w-5 h-5 mr-2" />
                    Пройти снова
                  </Button>
                  <Button
                    onClick={handleBackToSelection}
                    size="lg"
                    className="bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90"
                  >
                    Выбрать другой квиз
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {showConfetti && <ConfettiEffect />}
      </div>
    </Layout>
  );
}