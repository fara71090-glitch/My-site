import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Layout } from '@/components/Layout';
import { ExerciseCard } from '@/components/Cards';
import {
  MatchPairExercise,
  ChatRepairExercise,
  WordBuilderExercise,
  FillBlanksExercise,
  ImageQuizExercise,
  TrueFalseExercise,
} from '@/components/Exercises';
import { exercisesData } from '@/data/index';
import { useGameProgress } from '@/hooks/useGameProgress';
import type { Exercise } from '@/lib/index';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Trophy, Zap, Target } from 'lucide-react';
import { IMAGES } from '@/assets/images';

const exerciseComponents = {
  'match-pair': MatchPairExercise,
  'chat-repair': ChatRepairExercise,
  'word-builder': WordBuilderExercise,
  'fill-blanks': FillBlanksExercise,
  'image-quiz': ImageQuizExercise,
  'true-false': TrueFalseExercise,
};

export default function Training() {
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const { progress, addPoints, completeExercise, isExerciseCompleted } = useGameProgress();

  const handleStartExercise = (exercise: Exercise) => {
    setSelectedExercise(exercise);
  };

  const handleCloseExercise = () => {
    setSelectedExercise(null);
    setShowSuccess(false);
  };

  const handleComplete = (correct: boolean) => {
    if (selectedExercise) {
      completeExercise(selectedExercise.id, correct);
      if (correct) {
        addPoints(selectedExercise.points);
        setShowSuccess(true);
        setTimeout(() => {
          setShowSuccess(false);
          handleCloseExercise();
        }, 2000);
      }
    }
  };

  const ExerciseComponent = selectedExercise
    ? exerciseComponents[selectedExercise.type]
    : null;

  const completedCount = exercisesData.filter((ex) =>
    isExerciseCompleted(ex.id)
  ).length;
  const completionPercentage = (completedCount / exercisesData.length) * 100;

  return (
    <Layout>
      <div className="min-h-screen relative">
        <div
          className="absolute inset-0 z-0 opacity-20"
          style={{
            backgroundImage: `url(${IMAGES.QUIZ_BG_1})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-transparent to-background/70" />

        <div className="relative z-10 container mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/50">
                <Target className="w-8 h-8 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                  Зона тренировок
                </h1>
                <p className="text-muted-foreground text-lg mt-2">
                  Выполняй задания и зарабатывай очки
                </p>
              </div>
            </div>

            <div className="bg-card/50 backdrop-blur-sm border border-border rounded-2xl p-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Trophy className="w-6 h-6 text-primary" />
                  <span className="text-lg font-semibold">Прогресс выполнения</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-accent" />
                  <span className="text-2xl font-bold text-primary">
                    {completedCount}/{exercisesData.length}
                  </span>
                </div>
              </div>
              <Progress value={completionPercentage} className="h-3" />
              <p className="text-sm text-muted-foreground mt-2">
                {completionPercentage.toFixed(0)}% заданий выполнено
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {exercisesData.map((exercise, index) => (
              <motion.div
                key={exercise.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <ExerciseCard
                  exercise={exercise}
                  onStart={() => handleStartExercise(exercise)}
                />
              </motion.div>
            ))}
          </motion.div>
        </div>

        <Dialog open={!!selectedExercise} onOpenChange={handleCloseExercise}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {selectedExercise?.title}
              </DialogTitle>
              <p className="text-muted-foreground">{selectedExercise?.description}</p>
            </DialogHeader>

            <div className="mt-6">
              {ExerciseComponent && selectedExercise && (
                <ExerciseComponent
                  data={selectedExercise.data}
                  onComplete={handleComplete}
                />
              )}
            </div>

            <AnimatePresence>
              {showSuccess && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="absolute inset-0 flex items-center justify-center bg-background/95 backdrop-blur-sm z-50 rounded-lg"
                >
                  <div className="text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                      className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl shadow-primary/50"
                    >
                      <Trophy className="w-12 h-12 text-primary-foreground" />
                    </motion.div>
                    <motion.h3
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="text-3xl font-bold text-primary mb-2"
                    >
                      Отлично!
                    </motion.h3>
                    <motion.p
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="text-xl text-muted-foreground"
                    >
                      +{selectedExercise?.points} очков
                    </motion.p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
