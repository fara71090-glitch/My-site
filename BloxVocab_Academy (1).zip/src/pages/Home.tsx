import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { BookOpen, Target, Trophy, Calendar, Zap, Users, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Layout } from "@/components/Layout";
import { ROUTE_PATHS } from "@/lib/index";
import { IMAGES } from "@/assets/images";
import { springPresets, fadeInUp, staggerContainer, staggerItem } from "@/lib/motion";
import { useEffect, useState } from "react";

const features = [
  {
    icon: BookOpen,
    title: "Умный словарь",
    description: "База слов с живыми примерами из игровых чатов Roblox",
    color: "from-primary to-accent",
  },
  {
    icon: Target,
    title: "Зона тренировок",
    description: "Интерактивные задания для закрепления материала",
    color: "from-accent to-primary",
  },
  {
    icon: Trophy,
    title: "Квиз-битвы",
    description: "Соревнуйся на время и получай виртуальные бейджи",
    color: "from-primary to-accent",
  },
  {
    icon: Calendar,
    title: "Ежедневные челленджи",
    description: "Новое задание каждый день с особыми наградами",
    color: "from-accent to-primary",
  },
];

const steps = [
  {
    number: "01",
    title: "Изучай слова",
    description: "Открой словарь и познакомься с игровым сленгом",
    image: IMAGES.LEARNING_1,
  },
  {
    number: "02",
    title: "Тренируйся",
    description: "Выполняй интерактивные задания и закрепляй знания",
    image: IMAGES.LEARNING_3,
  },
  {
    number: "03",
    title: "Получай награды",
    description: "Зарабатывай очки, бейджи и повышай свой уровень",
    image: IMAGES.HERO_BG_7,
  },
];

const stats = [
  { value: 500, label: "Слов в словаре", suffix: "+" },
  { value: 50, label: "Интерактивных заданий", suffix: "+" },
  { value: 1000, label: "Активных учеников", suffix: "+" },
];

function AnimatedCounter({ end, duration = 2000 }: { end: number; duration?: number }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number;
    let animationFrame: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      setCount(Math.floor(easeOutQuart * end));

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration]);

  return <span>{count}</span>;
}

export default function Home() {
  return (
    <Layout>
      <div className="relative">
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src={IMAGES.HERO_BG_2}
              alt=""
              className="w-full h-full object-cover opacity-30"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-transparent to-background/70" />
          </div>

          <div className="absolute inset-0 z-0">
            <div className="absolute top-20 left-10 w-64 h-64 bg-primary/20 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              className="text-center max-w-4xl mx-auto"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={springPresets.gentle}
            >
              <motion.div
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ ...springPresets.snappy, delay: 0.2 }}
              >
                <Zap className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">Новая платформа для изучения английского</span>
              </motion.div>

              <motion.h1
                className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...springPresets.gentle, delay: 0.3 }}
              >
                Master Roblox English
              </motion.h1>

              <motion.p
                className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...springPresets.gentle, delay: 0.4 }}
              >
                Learn gaming vocabulary through interactive challenges
              </motion.p>

              <motion.div
                className="flex flex-col sm:flex-row gap-4 justify-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...springPresets.gentle, delay: 0.5 }}
              >
                <Button
                  asChild
                  size="lg"
                  className="text-lg px-8 py-6 bg-gradient-to-r from-primary to-accent hover:shadow-lg hover:shadow-primary/50 transition-all duration-300 hover:scale-105"
                >
                  <Link to={ROUTE_PATHS.TRAINING}>Начать обучение</Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 py-6 border-primary/50 hover:bg-primary/10 hover:border-primary transition-all duration-300 hover:scale-105"
                >
                  <Link to={ROUTE_PATHS.DICTIONARY}>Открыть словарь</Link>
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </section>

        <section className="py-24 relative">
          <div className="container mx-auto px-4">
            <motion.div
              className="text-center mb-16"
              variants={fadeInUp}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Возможности платформы
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Все инструменты для эффективного изучения английского через Roblox
              </p>
            </motion.div>

            <motion.div
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div key={index} variants={staggerItem}>
                    <Card className="p-6 h-full bg-card/50 backdrop-blur border-primary/20 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 hover:scale-105">
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 shadow-lg`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground">{feature.description}</p>
                    </Card>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>

        <section className="py-24 relative bg-gradient-to-b from-transparent via-primary/5 to-transparent">
          <div className="container mx-auto px-4">
            <motion.div
              className="text-center mb-16"
              variants={fadeInUp}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Как это работает
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Три простых шага к свободному владению игровым английским
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {steps.map((step, index) => (
                <motion.div
                  key={index}
                  className="relative"
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ ...springPresets.gentle, delay: index * 0.2 }}
                >
                  <Card className="p-6 h-full bg-card/50 backdrop-blur border-primary/20 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20">
                    <div className="relative h-48 mb-6 rounded-lg overflow-hidden">
                      <img
                        src={step.image}
                        alt={step.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                      <div className="absolute top-4 left-4 w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-2xl font-bold text-white shadow-lg">
                        {step.number}
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 relative">
          <div className="container mx-auto px-4">
            <motion.div
              className="text-center mb-16"
              variants={fadeInUp}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Статистика платформы
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Присоединяйся к растущему сообществу учеников
              </p>
            </motion.div>

            <motion.div
              className="grid grid-cols-1 md:grid-cols-3 gap-8"
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {stats.map((stat, index) => (
                <motion.div key={index} variants={staggerItem}>
                  <Card className="p-8 text-center bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20">
                    <div className="text-5xl md:text-6xl font-bold mb-2 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                      <AnimatedCounter end={stat.value} />
                      {stat.suffix}
                    </div>
                    <div className="text-lg text-muted-foreground font-medium">{stat.label}</div>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-24 relative">
          <div className="container mx-auto px-4">
            <motion.div
              className="max-w-4xl mx-auto text-center"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={springPresets.gentle}
            >
              <Card className="p-12 bg-gradient-to-br from-primary/20 to-accent/20 border-primary/30">
                <Award className="w-16 h-16 mx-auto mb-6 text-primary" />
                <h2 className="text-4xl md:text-5xl font-bold mb-6">
                  Готов стать мастером Roblox English?
                </h2>
                <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                  Начни свое путешествие прямо сейчас и получи первый бейдж уже сегодня!
                </p>
                <Button
                  asChild
                  size="lg"
                  className="text-lg px-8 py-6 bg-gradient-to-r from-primary to-accent hover:shadow-lg hover:shadow-primary/50 transition-all duration-300 hover:scale-105"
                >
                  <Link to={ROUTE_PATHS.TRAINING}>Начать обучение</Link>
                </Button>
              </Card>
            </motion.div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
