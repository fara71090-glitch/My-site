import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Layout } from '@/components/Layout';
import { BadgeCard } from '@/components/Cards';
import {
  MatchPairExercise,
  ChatRepairExercise,
  WordBuilderExercise,
  FillBlanksExercise,
  ImageQuizExercise,
  TrueFalseExercise,
} from '@/components/Exercises';
import { dailyChallengeData, badgesData } from '@/data/index';
import { useGameProgress } from '@/hooks/useGameProgress';
import type { DailyChallenge, ExerciseType } from '@/lib/index';
import { IMAGES } from '@/assets/images';
import { Calendar, Trophy, Flame, Clock, Star, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';

const getTodayChallenge = (): DailyChallenge | null => {
  const today = new Date().toISOString().split('T')[0];
  return dailyChallengeData.find((c) => c.date === today) || dailyChallengeData[0];
};

const getTimeUntilMidnight = (): number => {
  const now = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  return Math.floor((midnight.getTime() - now.getTime()) / 1000);
};

const formatTime = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

const ExerciseRenderer = ({
  type,
  data,
  onComplete,
}: {
  type: ExerciseType;
  data: any;
  onComplete: (correct: boolean) => void;
}) => {
  switch (type) {
    case 'match-pair':
      return <MatchPairExercise data={data} onComplete={onComplete} />;
    case 'chat-repair':
      return <ChatRepairExercise data={data} onComplete={onComplete} />;
    case 'word-builder':
      return <WordBuilderExercise data={data} onComplete={onComplete} />;
    case 'fill-blanks':
      return <FillBlanksExercise data={data} onComplete={onComplete} />;
    case 'image-quiz':
      return <ImageQuizExercise data={data} onComplete={onComplete} />;
    case 'true-false':
      return <TrueFalseExercise data={data} onComplete={onComplete} />;
    default:
      return null;
  }
};

export default function Daily() {
  const { progress, addPoints, unlockBadge, completeExercise } = useGameProgress();
  const [timeLeft, setTimeLeft] = useState(getTimeUntilMidnight());
  const [isExerciseOpen, setIsExerciseOpen] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const todayChallenge = useMemo(() => getTodayChallenge(), []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(getTimeUntilMidnight());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleStartChallenge = () => {
    setIsExerciseOpen(true);
  };

  const handleCompleteExercise = (correct: boolean) => {
    if (todayChallenge) {
      completeExercise(todayChallenge.id, correct);
      if (correct) {
        addPoints(todayChallenge.reward.points);
        if (todayChallenge.reward.badgeId) {
          unlockBadge(todayChallenge.reward.badgeId);
        }
        setIsCompleted(true);
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 3000);
      }
    }
    setIsExerciseOpen(false);
  };

  const rewardBadge = todayChallenge?.reward.badgeId
    ? badgesData.find((b) => b.id === todayChallenge.reward.badgeId)
    : null;

  const completedDates = useMemo(() => {
    const dates: string[] = [];
    const today = new Date();
    for (let i = 0; i < progress.streakDays; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      dates.push(date.toISOString().split('T')[0]);
    }
    return dates;
  }, [progress.streakDays]);

  const calendarDays = useMemo(() => {
    const days: { date: string; completed: boolean }[] = [];
    const today = new Date();
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      days.push({
        date: dateStr,
        completed: completedDates.includes(dateStr),
      });
    }
    return days;
  }, [completedDates]);

  if (!todayChallenge) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <p className="text-muted-foreground">Нет доступных заданий</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen relative overflow-hidden">
        <div
          className="absolute inset-0 z-0 opacity-20"
          style={{
            backgroundImage: `url(${IMAGES.HERO_BG_3})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-transparent to-background/70" />

        <div className="relative z-10 container mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              Ежедневное задание
            </h1>
            <p className="text-xl text-muted-foreground">Выполняй задания каждый день и получай награды!</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="lg:col-span-2"
            >
              <Card className="p-8 bg-card/80 backdrop-blur border-primary/20 shadow-lg shadow-primary/10">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
                      <Calendar className="w-8 h-8 text-primary-foreground" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-bold mb-1">{todayChallenge.title}</h2>
                      <p className="text-muted-foreground">{todayChallenge.description}</p>
                    </div>
                  </div>
                  {isCompleted && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                      className="flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/20 border border-green-500/50"
                    >
                      <Sparkles className="w-5 h-5 text-green-500" />
                      <span className="text-green-500 font-semibold">Выполнено!</span>
                    </motion.div>
                  )}
                </div>

                <div className="space-y-6">
                  <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
                    <Trophy className="w-6 h-6 text-primary" />
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">Награда</p>
                      <p className="text-lg font-semibold">{todayChallenge.reward.points} очков</p>
                    </div>
                    {rewardBadge && (
                      <div className="flex items-center gap-2">
                        <img src={IMAGES[rewardBadge.icon as keyof typeof IMAGES]} alt={rewardBadge.name} className="w-12 h-12 rounded-lg" />
                        <div>
                          <p className="text-sm font-semibold">{rewardBadge.name}</p>
                          <p className="text-xs text-muted-foreground">{rewardBadge.rarity}</p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
                    <Clock className="w-6 h-6 text-accent" />
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">Время до следующего задания</p>
                      <p className="text-2xl font-bold font-mono text-accent">{formatTime(timeLeft)}</p>
                    </div>
                  </div>

                  <Button
                    onClick={handleStartChallenge}
                    disabled={isCompleted}
                    size="lg"
                    className="w-full text-lg h-14 bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 shadow-lg shadow-primary/30 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
                  >
                    {isCompleted ? 'Задание выполнено' : 'Начать задание'}
                  </Button>
                </div>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="p-6 bg-card/80 backdrop-blur border-primary/20 shadow-lg shadow-primary/10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center shadow-lg shadow-orange-500/30">
                    <Flame className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Серия дней</h3>
                    <p className="text-3xl font-bold text-orange-500">{progress.streakDays} дней</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Прогресс до следующего уровня</p>
                    <Progress value={(progress.totalPoints % 1000) / 10} className="h-3" />
                    <p className="text-xs text-muted-foreground mt-1">
                      {progress.pointsToNextLevel} очков до уровня {progress.level + 1}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Статистика</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Выполнено заданий:</span>
                        <span className="font-semibold">{progress.statistics.totalExercises}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Точность:</span>
                        <span className="font-semibold">{progress.statistics.averageAccuracy.toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Бейджей:</span>
                        <span className="font-semibold">{progress.earnedBadges.length}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card className="p-8 bg-card/80 backdrop-blur border-primary/20 shadow-lg shadow-primary/10">
              <div className="flex items-center gap-3 mb-6">
                <Star className="w-6 h-6 text-primary" />
                <h3 className="text-2xl font-bold">История выполнения</h3>
              </div>

              <div className="grid grid-cols-10 gap-2">
                {calendarDays.map((day, index) => (
                  <motion.div
                    key={day.date}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.2, delay: index * 0.01 }}
                    className={`aspect-square rounded-lg flex items-center justify-center text-xs font-semibold transition-all duration-200 ${
                      day.completed
                        ? 'bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-lg shadow-primary/30'
                        : 'bg-muted/50 text-muted-foreground'
                    }`}
                    title={day.date}
                  >
                    {new Date(day.date).getDate()}
                  </motion.div>
                ))}
              </div>

              <div className="mt-6 flex items-center justify-center gap-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-gradient-to-br from-primary to-accent" />
                  <span>Выполнено</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-muted/50" />
                  <span>Пропущено</span>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        <AnimatePresence>
          {showConfetti && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center"
            >
              {[...Array(50)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{
                    x: 0,
                    y: 0,
                    scale: 0,
                    rotate: 0,
                  }}
                  animate={{
                    x: (Math.random() - 0.5) * 1000,
                    y: Math.random() * 1000,
                    scale: Math.random() * 2 + 0.5,
                    rotate: Math.random() * 360,
                  }}
                  transition={{
                    duration: 2,
                    ease: 'easeOut',
                  }}
                  className="absolute w-3 h-3 rounded-full"
                  style={{
                    backgroundColor: ['#00A2FF', '#FF00FF', '#00FF00', '#FFD700'][Math.floor(Math.random() * 4)],
                  }}
                />
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        <Dialog open={isExerciseOpen} onOpenChange={setIsExerciseOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">{todayChallenge.title}</DialogTitle>
            </DialogHeader>
            <div className="py-6">
              <ExerciseRenderer
                type={todayChallenge.exerciseType}
                data={todayChallenge.data}
                onComplete={handleCompleteExercise}
              />
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}