import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Volume2, X } from 'lucide-react';
import { Layout } from '@/components/Layout';
import { WordCard } from '@/components/Cards';
import { vocabularyData } from '@/data/index';
import { Word, WORD_CATEGORIES } from '@/lib/index';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

const categories = [
  { id: 'all', label: 'Все' },
  { id: WORD_CATEGORIES.SLANG, label: 'Сленг' },
  { id: WORD_CATEGORIES.TRADING, label: 'Торговля' },
  { id: WORD_CATEGORIES.MECHANICS, label: 'Механики' },
];

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.1,
    },
  },
};

const staggerItem = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: 'spring',
      stiffness: 300,
      damping: 35,
    },
  },
};

export default function Dictionary() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWord, setSelectedWord] = useState<Word | null>(null);

  const filteredWords = useMemo(() => {
    let filtered = vocabularyData;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((word) => word.category === selectedCategory);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (word) =>
          word.english.toLowerCase().includes(query) ||
          word.russian.toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [selectedCategory, searchQuery]);

  return (
    <Layout>
      <div className="min-h-screen bg-background py-12">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 35 }}
            className="mb-12 text-center"
          >
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              Умный Словарь
            </h1>
            <p className="text-xl text-muted-foreground">
              Изучай игровой английский через живые примеры из Roblox
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 35, delay: 0.1 }}
            className="mb-8 space-y-6"
          >
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Поиск слов..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-14 text-lg bg-card border-2 border-border focus:border-primary transition-all"
              />
            </div>

            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  variant={selectedCategory === category.id ? 'default' : 'outline'}
                  size="lg"
                  className="min-w-[120px] font-semibold transition-all hover:scale-105 active:scale-95"
                  style={{
                    boxShadow:
                      selectedCategory === category.id
                        ? '0 0 20px color-mix(in srgb, var(--primary) 40%, transparent)'
                        : 'none',
                  }}
                >
                  {category.label}
                </Button>
              ))}
            </div>
          </motion.div>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredWords.map((word) => (
              <motion.div
                key={word.id}
                variants={staggerItem}
                onClick={() => setSelectedWord(word)}
                className="cursor-pointer"
              >
                <WordCard word={word} />
              </motion.div>
            ))}
          </motion.div>

          {filteredWords.length === 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: 'spring', stiffness: 300, damping: 35 }}
              className="text-center py-20"
            >
              <p className="text-2xl text-muted-foreground">Слова не найдены</p>
              <p className="text-lg text-muted-foreground mt-2">
                Попробуйте изменить фильтры или поисковый запрос
              </p>
            </motion.div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {selectedWord && (
          <Dialog open={!!selectedWord} onOpenChange={() => setSelectedWord(null)}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <span className="text-4xl font-bold text-primary">
                      {selectedWord.english}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="hover:bg-primary/10 hover:scale-110 transition-all"
                    >
                      <Volume2 className="w-6 h-6 text-primary" />
                    </Button>
                  </div>
                  <Badge
                    variant="outline"
                    className="text-sm px-3 py-1 border-2 border-accent text-accent"
                  >
                    {selectedWord.category === WORD_CATEGORIES.SLANG && 'Сленг'}
                    {selectedWord.category === WORD_CATEGORIES.TRADING && 'Торговля'}
                    {selectedWord.category === WORD_CATEGORIES.MECHANICS && 'Механики'}
                  </Badge>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-6 mt-6">
                <div>
                  <p className="text-muted-foreground text-lg mb-2">
                    {selectedWord.transcription}
                  </p>
                  <p className="text-2xl font-semibold">{selectedWord.russian}</p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 text-primary">
                    Примеры из чатов
                  </h3>
                  <div className="space-y-4">
                    {selectedWord.examples.map((example, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{
                          type: 'spring',
                          stiffness: 300,
                          damping: 35,
                          delay: index * 0.1,
                        }}
                        className="bg-card border-2 border-border rounded-lg p-4 hover:border-primary transition-all"
                      >
                        <p className="text-lg font-medium mb-2">{example.english}</p>
                        <p className="text-muted-foreground">{example.russian}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {selectedWord.synonyms && selectedWord.synonyms.length > 0 && (
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-primary">Синонимы</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedWord.synonyms.map((synonym, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="text-base px-4 py-2"
                        >
                          {synonym}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        )}
      </AnimatePresence>
    </Layout>
  );
}
