import { motion } from 'framer-motion';
import { Layout } from '@/components/Layout';
import { BadgeCard, ProgressCard } from '@/components/Cards';
import { useGameProgress } from '@/hooks/useGameProgress';
import { badgesData } from '@/data/index';
import { IMAGES } from '@/assets/images';
import { Trophy, Target, TrendingUp, Calendar, Award, Zap } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

export default function Profile() {
  const { progress, isBadgeUnlocked } = useGameProgress();

  const levelProgress = ((progress.totalPoints % 1000) / 1000) * 100;

  const achievements = [
    {
      id: 'ach-1',
      title: 'Мастер слов',
      description: 'Выучить 50 слов',
      current: Math.min(progress.statistics.totalExercises, 50),
      target: 50,
      icon: Trophy,
    },
    {
      id: 'ach-2',
      title: 'Точность',
      description: 'Достичь 90% правильных ответов',
      current: Math.min(progress.statistics.averageAccuracy, 90),
      target: 90,
      icon: Target,
    },
    {
      id: 'ach-3',
      title: 'Коллекционер бейджей',
      description: 'Получить 5 бейджей',
      current: Math.min(progress.earnedBadges.length, 5),
      target: 5,
      icon: Award,
    },
    {
      id: 'ach-4',
      title: 'Марафонец',
      description: 'Streak 14 дней',
      current: Math.min(progress.streakDays, 14),
      target: 14,
      icon: Calendar,
    },
  ];

  return (
    <Layout>
      <div className="min-h-screen bg-background py-12">
        <div className="container mx-auto px-4 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
          >
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary/20 via-accent/10 to-background border border-primary/20 p-8">
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-30" />
              
              <div className="relative flex flex-col md:flex-row items-center gap-8">
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
                  className="relative"
                >
                  <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-accent p-1 shadow-[0_0_30px_rgba(0,162,255,0.5)]">
                    <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
                      <img
                        src={IMAGES.BADGES_3}
                        alt="Аватар"
                        className="w-24 h-24 rounded-full object-cover"
                      />
                    </div>
                  </div>
                  <div className="absolute -bottom-2 -right-2 bg-primary text-primary-foreground rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg shadow-lg">
                    {progress.level}
                  </div>
                </motion.div>

                <div className="flex-1 text-center md:text-left space-y-4">
                  <div>
                    <h1 className="text-4xl font-bold text-foreground mb-2">Игрок BloxVocab</h1>
                    <p className="text-xl text-muted-foreground">Уровень {progress.level} • {progress.totalPoints.toLocaleString()} очков</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Прогресс до уровня {progress.level + 1}</span>
                      <span className="text-primary font-semibold">{progress.pointsToNextLevel} очков осталось</span>
                    </div>
                    <div className="relative h-4 bg-background/50 rounded-full overflow-hidden border border-primary/20">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${levelProgress}%` }}
                        transition={{ duration: 1, delay: 0.5, ease: 'easeOut' }}
                        className="h-full bg-gradient-to-r from-primary via-accent to-primary rounded-full relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer" />
                      </motion.div>
                    </div>
                  </div>
                </div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  className="flex gap-4"
                >
                  <div className="text-center p-4 bg-background/50 rounded-2xl border border-primary/20">
                    <div className="flex items-center justify-center w-12 h-12 bg-primary/20 rounded-full mb-2 mx-auto">
                      <Zap className="w-6 h-6 text-primary" />
                    </div>
                    <div className="text-2xl font-bold text-foreground">{progress.streakDays}</div>
                    <div className="text-xs text-muted-foreground">Дней подряд</div>
                  </div>
                  <div className="text-center p-4 bg-background/50 rounded-2xl border border-accent/20">
                    <div className="flex items-center justify-center w-12 h-12 bg-accent/20 rounded-full mb-2 mx-auto">
                      <Trophy className="w-6 h-6 text-accent" />
                    </div>
                    <div className="text-2xl font-bold text-foreground">{progress.earnedBadges.length}</div>
                    <div className="text-xs text-muted-foreground">Бейджей</div>
                  </div>
                </motion.div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="lg:col-span-2 space-y-6"
              >
                <div>
                  <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                    <Trophy className="w-8 h-8 text-primary" />
                    Заработанные бейджи
                  </h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {badgesData.map((badge, index) => (
                      <motion.div
                        key={badge.id}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.3 + index * 0.05 }}
                      >
                        <BadgeCard badge={badge} unlocked={isBadgeUnlocked(badge.id)} />
                      </motion.div>
                    ))}
                  </div>
                </div>

                <Separator className="my-8" />

                <div>
                  <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                    <Target className="w-8 h-8 text-accent" />
                    Достижения
                  </h2>
                  <div className="space-y-4">
                    {achievements.map((achievement, index) => {
                      const Icon = achievement.icon;
                      const progressPercent = (achievement.current / achievement.target) * 100;
                      const isCompleted = achievement.current >= achievement.target;

                      return (
                        <motion.div
                          key={achievement.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.4 + index * 0.1 }}
                        >
                          <Card className="p-6 bg-card/50 border-border hover:border-primary/50 transition-all duration-300">
                            <div className="flex items-start gap-4">
                              <div className={`flex items-center justify-center w-14 h-14 rounded-2xl ${
                                isCompleted ? 'bg-primary/20' : 'bg-muted/50'
                              }`}>
                                <Icon className={`w-7 h-7 ${
                                  isCompleted ? 'text-primary' : 'text-muted-foreground'
                                }`} />
                              </div>
                              <div className="flex-1 space-y-3">
                                <div>
                                  <h3 className="text-lg font-semibold text-foreground">{achievement.title}</h3>
                                  <p className="text-sm text-muted-foreground">{achievement.description}</p>
                                </div>
                                <div className="space-y-2">
                                  <div className="flex items-center justify-between text-sm">
                                    <span className="text-muted-foreground">
                                      {achievement.current} / {achievement.target}
                                    </span>
                                    <span className={`font-semibold ${
                                      isCompleted ? 'text-primary' : 'text-foreground'
                                    }`}>
                                      {Math.round(progressPercent)}%
                                    </span>
                                  </div>
                                  <Progress value={progressPercent} className="h-2" />
                                </div>
                              </div>
                            </div>
                          </Card>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-3xl font-bold text-foreground mb-6 flex items-center gap-3">
                    <TrendingUp className="w-8 h-8 text-primary" />
                    Статистика
                  </h2>
                  <Card className="p-6 bg-card/50 border-border space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-background/50 rounded-xl">
                        <div>
                          <p className="text-sm text-muted-foreground">Всего заданий</p>
                          <p className="text-2xl font-bold text-foreground">{progress.statistics.totalExercises}</p>
                        </div>
                        <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                          <Target className="w-6 h-6 text-primary" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-background/50 rounded-xl">
                        <div>
                          <p className="text-sm text-muted-foreground">Правильных ответов</p>
                          <p className="text-2xl font-bold text-foreground">{progress.statistics.correctAnswers}</p>
                        </div>
                        <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                          <Trophy className="w-6 h-6 text-accent" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-background/50 rounded-xl">
                        <div>
                          <p className="text-sm text-muted-foreground">Точность</p>
                          <p className="text-2xl font-bold text-foreground">
                            {progress.statistics.averageAccuracy.toFixed(1)}%
                          </p>
                        </div>
                        <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                          <TrendingUp className="w-6 h-6 text-primary" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-background/50 rounded-xl">
                        <div>
                          <p className="text-sm text-muted-foreground">Всего ответов</p>
                          <p className="text-2xl font-bold text-foreground">{progress.statistics.totalAnswers}</p>
                        </div>
                        <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                          <Zap className="w-6 h-6 text-accent" />
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <h3 className="text-lg font-semibold text-foreground">Прогресс обучения</h3>
                      <div className="space-y-4">
                        <div>
                          <div className="flex items-center justify-between text-sm mb-2">
                            <span className="text-muted-foreground">Выполнено заданий</span>
                            <span className="text-foreground font-semibold">{progress.completedExercises.length}</span>
                          </div>
                          <Progress value={(progress.completedExercises.length / 20) * 100} className="h-2" />
                        </div>
                        <div>
                          <div className="flex items-center justify-between text-sm mb-2">
                            <span className="text-muted-foreground">Пройдено квизов</span>
                            <span className="text-foreground font-semibold">{progress.completedQuizzes.length}</span>
                          </div>
                          <Progress value={(progress.completedQuizzes.length / 10) * 100} className="h-2" />
                        </div>
                        <div>
                          <div className="flex items-center justify-between text-sm mb-2">
                            <span className="text-muted-foreground">Получено бейджей</span>
                            <span className="text-foreground font-semibold">{progress.earnedBadges.length} / {badgesData.length}</span>
                          </div>
                          <Progress value={(progress.earnedBadges.length / badgesData.length) * 100} className="h-2" />
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>

                <Card className="p-6 bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
                  <div className="text-center space-y-3">
                    <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                      <Calendar className="w-8 h-8 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Текущий streak</p>
                      <p className="text-4xl font-bold text-foreground">{progress.streakDays}</p>
                      <p className="text-sm text-muted-foreground">дней подряд</p>
                    </div>
                    <p className="text-xs text-muted-foreground">Продолжай заниматься каждый день!</p>
                  </div>
                </Card>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
