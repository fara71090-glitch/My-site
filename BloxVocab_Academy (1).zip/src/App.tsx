import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter, Routes, Route } from "react-router-dom";
import { MotionConfig } from "framer-motion";
import { useEffect } from "react";
import { ROUTE_PATHS } from "@/lib/index";
import Home from "@/pages/Home";
import Dictionary from "@/pages/Dictionary";
import Training from "@/pages/Training";
import Quiz from "@/pages/Quiz";
import Daily from "@/pages/Daily";
import Profile from "@/pages/Profile";

const queryClient = new QueryClient();

const App = () => {
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <MotionConfig reducedMotion="user">
          <Toaster />
          <Sonner />
          <HashRouter>
            <Routes>
              <Route path={ROUTE_PATHS.HOME} element={<Home />} />
              <Route path={ROUTE_PATHS.DICTIONARY} element={<Dictionary />} />
              <Route path={ROUTE_PATHS.TRAINING} element={<Training />} />
              <Route path={ROUTE_PATHS.QUIZ} element={<Quiz />} />
              <Route path={ROUTE_PATHS.DAILY} element={<Daily />} />
              <Route path={ROUTE_PATHS.PROFILE} element={<Profile />} />
            </Routes>
          </HashRouter>
        </MotionConfig>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;