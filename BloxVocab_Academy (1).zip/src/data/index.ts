import { Word, Exercise, Quiz, Badge, DailyChallenge, WORD_CATEGORIES } from '@/lib/index';

export const vocabularyData: Word[] = [
  {
    id: 'word-1',
    english: 'AFK',
    russian: 'Отошел от клавиатуры',
    transcription: '/eɪ ef keɪ/',
    category: WORD_CATEGORIES.SLANG,
    examples: [
      {
        english: 'I\'m going AFK for 5 minutes',
        russian: 'Я отойду на 5 минут',
      },
      {
        english: 'Player is AFK, don\'t wait',
        russian: 'Игрок отошел, не ждите',
      },
    ],
    synonyms: ['Away', 'Idle', 'Inactive'],
  },
  {
    id: 'word-2',
    english: 'Trade',
    russian: 'Обмен, торговля',
    transcription: '/treɪd/',
    category: WORD_CATEGORIES.TRADING,
    examples: [
      {
        english: 'Want to trade my Neon Cat for your Dragon?',
        russian: 'Хочешь обменять мою Неоновую Кошку на твоего Дракона?',
      },
      {
        english: 'Trading rare pets only',
        russian: 'Обмениваю только редких питомцев',
      },
    ],
    synonyms: ['Exchange', 'Swap', 'Deal'],
  },
  {
    id: 'word-3',
    english: 'Noob',
    russian: 'Новичок',
    transcription: '/nuːb/',
    category: WORD_CATEGORIES.SLANG,
    examples: [
      {
        english: 'Don\'t be mean to noobs',
        russian: 'Не будь злым к новичкам',
      },
      {
        english: 'I was a noob last year',
        russian: 'Я был новичком в прошлом году',
      },
    ],
    synonyms: ['Newbie', 'Beginner', 'Rookie'],
  },
  {
    id: 'word-4',
    english: 'GG',
    russian: 'Хорошая игра',
    transcription: '/dʒiː dʒiː/',
    category: WORD_CATEGORIES.SLANG,
    examples: [
      {
        english: 'GG everyone, that was fun!',
        russian: 'Хорошая игра всем, было весело!',
      },
      {
        english: 'GG, you won fair and square',
        russian: 'Хорошая игра, ты выиграл честно',
      },
    ],
    synonyms: ['Good Game', 'Well Played'],
  },
  {
    id: 'word-5',
    english: 'Obby',
    russian: 'Полоса препятствий',
    transcription: '/ˈɒbi/',
    category: WORD_CATEGORIES.MECHANICS,
    examples: [
      {
        english: 'This obby is too hard!',
        russian: 'Эта полоса препятствий слишком сложная!',
      },
      {
        english: 'Join my obby game',
        russian: 'Присоединяйся к моей игре с препятствиями',
      },
    ],
    synonyms: ['Obstacle Course', 'Parkour'],
  },
  {
    id: 'word-6',
    english: 'Pet',
    russian: 'Питомец',
    transcription: '/pet/',
    category: WORD_CATEGORIES.TRADING,
    examples: [
      {
        english: 'My pet is legendary!',
        russian: 'Мой питомец легендарный!',
      },
      {
        english: 'Looking for rare pets',
        russian: 'Ищу редких питомцев',
      },
    ],
    synonyms: ['Animal', 'Companion'],
  },
  {
    id: 'word-7',
    english: 'Adopt',
    russian: 'Усыновить, взять',
    transcription: '/əˈdɒpt/',
    category: WORD_CATEGORIES.TRADING,
    examples: [
      {
        english: 'I want to adopt a unicorn',
        russian: 'Я хочу взять единорога',
      },
      {
        english: 'Adopt Me is my favorite game',
        russian: 'Adopt Me - моя любимая игра',
      },
    ],
    synonyms: ['Take', 'Get', 'Acquire'],
  },
  {
    id: 'word-8',
    english: 'Scam',
    russian: 'Обман, мошенничество',
    transcription: '/skæm/',
    category: WORD_CATEGORIES.TRADING,
    examples: [
      {
        english: 'Don\'t trust him, it\'s a scam!',
        russian: 'Не доверяй ему, это обман!',
      },
      {
        english: 'Report scammers to admins',
        russian: 'Сообщайте о мошенниках администраторам',
      },
    ],
    synonyms: ['Fraud', 'Cheat', 'Trick'],
  },
  {
    id: 'word-9',
    english: 'Flex',
    russian: 'Хвастаться',
    transcription: '/fleks/',
    category: WORD_CATEGORIES.SLANG,
    examples: [
      {
        english: 'Stop flexing your Robux',
        russian: 'Перестань хвастаться своими Robux',
      },
      {
        english: 'He\'s flexing his new car',
        russian: 'Он хвастается своей новой машиной',
      },
    ],
    synonyms: ['Show off', 'Brag', 'Boast'],
  },
  {
    id: 'word-10',
    english: 'Legendary',
    russian: 'Легендарный',
    transcription: '/ˈledʒəndəri/',
    category: WORD_CATEGORIES.TRADING,
    examples: [
      {
        english: 'I finally got a legendary pet!',
        russian: 'Я наконец получил легендарного питомца!',
      },
      {
        english: 'Legendary items are very rare',
        russian: 'Легендарные предметы очень редкие',
      },
    ],
    synonyms: ['Epic', 'Rare', 'Mythical'],
  },
];

export const exercisesData: Exercise[] = [
  {
    id: 'exercise-1',
    type: 'match-pair',
    title: 'Соедини пары',
    description: 'Соедини английское слово с русским переводом',
    difficulty: 'beginner',
    points: 50,
    data: {
      pairs: [
        { english: 'AFK', russian: 'Отошел от клавиатуры' },
        { english: 'Trade', russian: 'Обмен' },
        { english: 'Noob', russian: 'Новичок' },
        { english: 'GG', russian: 'Хорошая игра' },
        { english: 'Pet', russian: 'Питомец' },
      ],
    },
  },
  {
    id: 'exercise-2',
    type: 'chat-repair',
    title: 'Исправь чат',
    description: 'Найди и исправь ошибку в предложении из игрового чата',
    difficulty: 'intermediate',
    points: 75,
    data: {
      sentences: [
        {
          incorrect: 'I want to traid my pet',
          correct: 'I want to trade my pet',
          explanation: 'Правильно: trade (обмен)',
        },
        {
          incorrect: 'This obby is to hard',
          correct: 'This obby is too hard',
          explanation: 'Правильно: too (слишком)',
        },
        {
          incorrect: 'GG everyones',
          correct: 'GG everyone',
          explanation: 'Правильно: everyone (все)',
        },
      ],
    },
  },
  {
    id: 'exercise-3',
    type: 'word-builder',
    title: 'Собери слово',
    description: 'Собери слово из перемешанных букв',
    difficulty: 'beginner',
    points: 40,
    data: {
      words: [
        { scrambled: 'DARTE', answer: 'TRADE', hint: 'Обмен' },
        { scrambled: 'OBNO', answer: 'NOOB', hint: 'Новичок' },
        { scrambled: 'XELF', answer: 'FLEX', hint: 'Хвастаться' },
        { scrambled: 'TPODA', answer: 'ADOPT', hint: 'Усыновить' },
      ],
    },
  },
  {
    id: 'exercise-4',
    type: 'fill-blanks',
    title: 'Заполни пропуск',
    description: 'Выбери правильное слово для пропуска',
    difficulty: 'intermediate',
    points: 60,
    data: {
      questions: [
        {
          sentence: 'I want to ____ my Neon Cat for your Dragon',
          options: ['Trade', 'Eat', 'Run', 'Jump'],
          correct: 'Trade',
        },
        {
          sentence: 'This ____ is too difficult for beginners',
          options: ['Obby', 'Food', 'Car', 'House'],
          correct: 'Obby',
        },
        {
          sentence: 'Don\'t trust him, it\'s a ____!',
          options: ['Scam', 'Game', 'Friend', 'Pet'],
          correct: 'Scam',
        },
      ],
    },
  },
  {
    id: 'exercise-5',
    type: 'image-quiz',
    title: 'Угадай по картинке',
    description: 'Выбери правильное значение элемента интерфейса',
    difficulty: 'beginner',
    points: 45,
    data: {
      questions: [
        {
          imageKey: 'GAME_CHARACTERS_1',
          question: 'Что означает кнопка Settings?',
          options: ['Настройки', 'Выход', 'Помощь', 'Магазин'],
          correct: 'Настройки',
        },
        {
          imageKey: 'GAME_CHARACTERS_2',
          question: 'Что означает Inventory?',
          options: ['Инвентарь', 'Друзья', 'Чат', 'Карта'],
          correct: 'Инвентарь',
        },
      ],
    },
  },
  {
    id: 'exercise-6',
    type: 'true-false',
    title: 'Правда или ложь',
    description: 'Определи, правдиво ли утверждение',
    difficulty: 'beginner',
    points: 35,
    data: {
      statements: [
        {
          statement: 'AFK означает, что игрок играет очень быстро',
          correct: false,
          explanation: 'AFK означает Away From Keyboard - отошел от клавиатуры',
        },
        {
          statement: 'GG означает Good Game - хорошая игра',
          correct: true,
          explanation: 'Правильно! GG - это сокращение от Good Game',
        },
        {
          statement: 'Noob - это опытный игрок',
          correct: false,
          explanation: 'Noob означает новичок, начинающий игрок',
        },
        {
          statement: 'Trade означает обмен предметами',
          correct: true,
          explanation: 'Верно! Trade - это обмен или торговля',
        },
      ],
    },
  },
];

export const quizzesData: Quiz[] = [
  {
    id: 'quiz-1',
    title: 'Базовый словарь Roblox',
    description: 'Проверь знание основных игровых терминов',
    difficulty: 'beginner',
    timeLimit: 300,
    questions: [
      {
        id: 'q1',
        question: 'Что означает AFK?',
        options: [
          'Отошел от клавиатуры',
          'Очень быстрый игрок',
          'Новый друг',
          'Хорошая игра',
        ],
        correctAnswer: 'Отошел от клавиатуры',
        explanation: 'AFK = Away From Keyboard',
      },
      {
        id: 'q2',
        question: 'Как сказать "хорошая игра" в чате?',
        options: ['GG', 'GL', 'WP', 'TY'],
        correctAnswer: 'GG',
        explanation: 'GG = Good Game',
      },
      {
        id: 'q3',
        question: 'Что такое Obby?',
        options: [
          'Полоса препятствий',
          'Редкий питомец',
          'Игровая валюта',
          'Тип оружия',
        ],
        correctAnswer: 'Полоса препятствий',
        explanation: 'Obby = Obstacle Course',
      },
      {
        id: 'q4',
        question: 'Кто такой Noob?',
        options: ['Новичок', 'Профессионал', 'Читер', 'Администратор'],
        correctAnswer: 'Новичок',
        explanation: 'Noob = новичок, начинающий игрок',
      },
      {
        id: 'q5',
        question: 'Что означает Trade?',
        options: ['Обмен', 'Бег', 'Прыжок', 'Атака'],
        correctAnswer: 'Обмен',
        explanation: 'Trade = обмен предметами или питомцами',
      },
    ],
    reward: {
      points: 200,
      badgeId: 'badge-1',
    },
  },
  {
    id: 'quiz-2',
    title: 'Торговый эксперт',
    description: 'Проверь знания терминов торговли',
    difficulty: 'intermediate',
    timeLimit: 240,
    questions: [
      {
        id: 'q1',
        question: 'Что означает Legendary?',
        options: ['Легендарный', 'Обычный', 'Дешевый', 'Сломанный'],
        correctAnswer: 'Легендарный',
        explanation: 'Legendary = самая редкая категория предметов',
      },
      {
        id: 'q2',
        question: 'Что такое Scam?',
        options: ['Обман', 'Честная сделка', 'Подарок', 'Игра'],
        correctAnswer: 'Обман',
        explanation: 'Scam = мошенничество в торговле',
      },
      {
        id: 'q3',
        question: 'Что означает Flex?',
        options: ['Хвастаться', 'Прятаться', 'Помогать', 'Учиться'],
        correctAnswer: 'Хвастаться',
        explanation: 'Flex = показывать свои достижения',
      },
      {
        id: 'q4',
        question: 'Что такое Pet в Roblox?',
        options: ['Питомец', 'Оружие', 'Транспорт', 'Здание'],
        correctAnswer: 'Питомец',
        explanation: 'Pet = виртуальный питомец в игре',
      },
    ],
    reward: {
      points: 300,
      badgeId: 'badge-2',
    },
  },
  {
    id: 'quiz-3',
    title: 'Мастер чата',
    description: 'Продвинутый тест на знание игрового сленга',
    difficulty: 'advanced',
    timeLimit: 180,
    questions: [
      {
        id: 'q1',
        question: 'Какое предложение правильное?',
        options: [
          'I want to trade my pet',
          'I want to traid my pet',
          'I want too trade my pet',
          'I want to traded my pet',
        ],
        correctAnswer: 'I want to trade my pet',
        explanation: 'Правильная форма глагола trade',
      },
      {
        id: 'q2',
        question: 'Как правильно написать "все"?',
        options: ['everyone', 'everyones', 'every one', 'every ones'],
        correctAnswer: 'everyone',
        explanation: 'Everyone пишется слитно',
      },
      {
        id: 'q3',
        question: 'Что означает "too hard"?',
        options: ['Слишком сложно', 'Два сложных', 'Тоже сложно', 'К сложному'],
        correctAnswer: 'Слишком сложно',
        explanation: 'Too = слишком',
      },
    ],
    reward: {
      points: 500,
      badgeId: 'badge-3',
    },
  },
];

export const badgesData: Badge[] = [
  {
    id: 'badge-1',
    name: 'English Pro',
    description: 'Пройди базовый квиз на 80%+',
    icon: 'BADGES_1',
    rarity: 'common',
    requirement: 'Набрать 80% в базовом квизе',
  },
  {
    id: 'badge-2',
    name: 'Legendary Trader',
    description: 'Стань экспертом в торговых терминах',
    icon: 'BADGES_2',
    rarity: 'rare',
    requirement: 'Пройти квиз "Торговый эксперт" на 90%+',
  },
  {
    id: 'badge-3',
    name: 'Chat Master',
    description: 'Освой продвинутый игровой сленг',
    icon: 'BADGES_3',
    rarity: 'epic',
    requirement: 'Пройти квиз "Мастер чата" на 95%+',
  },
  {
    id: 'badge-4',
    name: 'Word Builder',
    description: 'Собери 50 слов правильно',
    icon: 'BADGES_4',
    rarity: 'common',
    requirement: 'Выполнить 50 заданий Word Builder',
  },
  {
    id: 'badge-5',
    name: 'Streak Champion',
    description: 'Занимайся 7 дней подряд',
    icon: 'BADGES_5',
    rarity: 'rare',
    requirement: 'Поддерживать streak 7 дней',
  },
  {
    id: 'badge-6',
    name: 'Perfect Score',
    description: 'Получи 100% в любом квизе',
    icon: 'BADGES_6',
    rarity: 'epic',
    requirement: 'Пройти квиз без ошибок',
  },
  {
    id: 'badge-7',
    name: 'Vocabulary Master',
    description: 'Выучи все 100 слов',
    icon: 'BADGES_7',
    rarity: 'legendary',
    requirement: 'Изучить весь словарь',
  },
  {
    id: 'badge-8',
    name: 'Daily Warrior',
    description: 'Выполни 30 ежедневных заданий',
    icon: 'BADGES_8',
    rarity: 'epic',
    requirement: 'Выполнить 30 Daily Challenges',
  },
];

export const dailyChallengeData: DailyChallenge[] = [
  {
    id: 'daily-1',
    date: '2026-04-06',
    title: 'Торговый день',
    description: 'Выучи 5 слов из категории Trading',
    exerciseType: 'match-pair',
    data: {
      pairs: [
        { english: 'Trade', russian: 'Обмен' },
        { english: 'Pet', russian: 'Питомец' },
        { english: 'Adopt', russian: 'Усыновить' },
        { english: 'Scam', russian: 'Обман' },
        { english: 'Legendary', russian: 'Легендарный' },
      ],
    },
    reward: {
      points: 100,
    },
    expiresAt: '2026-04-07T00:00:00Z',
  },
  {
    id: 'daily-2',
    date: '2026-04-07',
    title: 'Исправь чат',
    description: 'Найди ошибки в игровых сообщениях',
    exerciseType: 'chat-repair',
    data: {
      sentences: [
        {
          incorrect: 'I want to traid my legendary pet',
          correct: 'I want to trade my legendary pet',
          explanation: 'Правильно: trade',
        },
        {
          incorrect: 'This obby is to hard for me',
          correct: 'This obby is too hard for me',
          explanation: 'Правильно: too (слишком)',
        },
      ],
    },
    reward: {
      points: 120,
    },
    expiresAt: '2026-04-08T00:00:00Z',
  },
  {
    id: 'daily-3',
    date: '2026-04-08',
    title: 'Быстрый квиз',
    description: 'Ответь на 5 вопросов за 2 минуты',
    exerciseType: 'true-false',
    data: {
      statements: [
        {
          statement: 'AFK означает Away From Keyboard',
          correct: true,
          explanation: 'Верно!',
        },
        {
          statement: 'Noob - это опытный игрок',
          correct: false,
          explanation: 'Noob = новичок',
        },
        {
          statement: 'GG означает Good Game',
          correct: true,
          explanation: 'Правильно!',
        },
        {
          statement: 'Flex означает прятаться',
          correct: false,
          explanation: 'Flex = хвастаться',
        },
        {
          statement: 'Trade означает обмен',
          correct: true,
          explanation: 'Верно!',
        },
      ],
    },
    reward: {
      points: 150,
      badgeId: 'badge-4',
    },
    expiresAt: '2026-04-09T00:00:00Z',
  },
];